from turtle import Turtle
import math

#	Creating Turtle Object
t = Turtle()
t.speed(1)

# Establishing PI
pie = math.pi

def drawCircleA(t, centerpoint, radius):
	'''Calculate distance with formula 2.0 * pi * radius/ 120.0
	The turtle should draw a circumference of the circle by turning 3 degrees and moving 120 times a given distance.'''
	t.goto(centerpoint)
	t.up()
	t.forward(radius)
	t.down()
	t.left(90)
	for x in range(121):
		
		t.left(3)
		t.forward(1)

		
	distanceMoved = (2.0* pie * radius)/120
	print(f"The turtle moved {distanceMoved}.")
	return distanceMoved
	

drawCircleA(t, (0,0), 20)